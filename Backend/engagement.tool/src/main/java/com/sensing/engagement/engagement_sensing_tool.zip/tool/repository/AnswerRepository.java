package com.sensing.engagement.tool.repository;

import com.sensing.engagement.tool.model.Answer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface AnswerRepository extends JpaRepository<Answer, UUID> {

    List<Answer> findBySurveyId(UUID surveyId);
    Optional<Answer> findByIdAndSurveyId(UUID answerId, UUID surveyId);
}